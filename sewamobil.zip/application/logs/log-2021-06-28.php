<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 07:50:14 --> Severity: Warning --> Missing argument 1 for Kendaraan::booking(), called in C:\xampp\htdocs\alter_private\sewamobil\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 80
ERROR - 2021-06-28 07:50:44 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 07:50:47 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 07:50:59 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 07:51:50 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 07:54:54 --> 404 Page Not Found: Index/product
ERROR - 2021-06-28 07:59:34 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 08:02:22 --> Severity: Warning --> Missing argument 1 for Kendaraan::booking(), called in C:\xampp\htdocs\alter_private\sewamobil\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 80
ERROR - 2021-06-28 08:02:30 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 08:02:34 --> Severity: Warning --> Missing argument 1 for Kendaraan::booking(), called in C:\xampp\htdocs\alter_private\sewamobil\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 80
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 147
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 29
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 30
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 45
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 46
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 57
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 60
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 63
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 66
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 79
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 88
ERROR - 2021-06-28 08:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 92
ERROR - 2021-06-28 08:36:39 --> Severity: Error --> Class 'App\Controllers\BaseController' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 5
ERROR - 2021-06-28 08:38:33 --> Severity: Compile Error --> Cannot use "parent" when no class scope is active C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 7
ERROR - 2021-06-28 08:38:56 --> Severity: Error --> Class 'BaseController' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 5
ERROR - 2021-06-28 08:39:07 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:39:31 --> Severity: Error --> Class 'CI_controllers' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 5
ERROR - 2021-06-28 08:39:34 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:41:11 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:41:13 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:41:13 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:41:18 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:41:23 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:42:26 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:42:27 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:42:27 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:42:27 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:50:07 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:50:08 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:50:08 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:50:09 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 08:51:12 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 08:55:21 --> Severity: Warning --> The use statement with non-compound name 'Exception' has no effect C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 25
ERROR - 2021-06-28 08:55:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 08:56:08 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:03:45 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:03:48 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:03:48 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:03:49 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:03:49 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:03:50 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:04:55 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:04:57 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:04:57 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:04:59 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:04:59 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:00 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:13 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:13 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:25 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:26 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:26 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:28 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:05:29 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:05:44 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:48 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:48 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:48 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:49 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:05:49 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:06:07 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:11 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:11 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:11 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:13 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:13 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:14 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:14 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:15 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:15 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:15 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:16 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:16 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:16 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:16 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:16 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:17 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:17 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:07:17 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:09:58 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:09:58 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:09:58 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:09:59 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:39 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:10:41 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:19 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:25 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:11:25 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:26 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:27 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:28 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:28 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:29 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:31 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:11:49 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:15:29 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:42 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:45 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:45 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:46 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:46 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:46 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:15:47 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:05 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:06 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:06 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:06 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:07 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:07 --> Severity: Error --> Class 'grocery_CRUD_States' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 37
ERROR - 2021-06-28 09:16:18 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:16:37 --> Severity: Error --> Class 'grocery_CRUD_Field_Types' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 427
ERROR - 2021-06-28 09:18:11 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:18:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:18:12 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:18:24 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:18:24 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:18:25 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:18:28 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:18:34 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:18:35 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:18:35 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:13 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:15 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:15 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:15 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:16 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:30 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:31 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:31 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:19:32 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:20:19 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:20:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:20:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:20:44 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:20:45 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:20:46 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:38 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:39 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:40 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:50 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:51 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:22:51 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:32 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:33 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:33 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:34 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:50 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:51 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:51 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:51 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:23:52 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:24:52 --> Severity: Compile Error --> Cannot declare class grocery_CRUD_Model_Driver, because the name is already in use C:\xampp\htdocs\alter_private\sewamobil\application\config\grocery_crud.php 1492
ERROR - 2021-06-28 09:25:44 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:25:46 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:19 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:20 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:22 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:24 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:24 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:26:24 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:03 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:03 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:03 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:04 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:04 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:04 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:04 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:39 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:45 --> 404 Page Not Found: admin/Admis/index
ERROR - 2021-06-28 09:27:50 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:27:55 --> 404 Page Not Found: admin//index
ERROR - 2021-06-28 09:28:17 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:28:24 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:28:29 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:28:32 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:31:39 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:31:42 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:31:45 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:31:49 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:35:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:35:25 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-28 09:49:26 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 09:49:36 --> 404 Page Not Found: admin/Booking/index
ERROR - 2021-06-28 09:51:01 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 09:51:57 --> Severity: Error --> Class 'App\Controllers\BaseController' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 5
ERROR - 2021-06-28 09:52:27 --> Severity: Error --> Class 'App\Controllers\Super' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 5
ERROR - 2021-06-28 09:53:05 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:53:07 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:53:08 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:53:08 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:53:08 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:54:16 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:54:17 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:54:17 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:54:17 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:54:18 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:54:18 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:08 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:09 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:09 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:10 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:10 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:10 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:55:39 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:56:08 --> 404 Page Not Found: admin/Booking/customers_management
ERROR - 2021-06-28 09:56:32 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 09:57:26 --> Severity: error --> Exception: Using $this when not in object context C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 6
ERROR - 2021-06-28 09:58:06 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 09:58:27 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 09:58:27 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 09:58:27 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:22 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:23 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:25 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:52 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:52 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:53 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:00:53 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:01:08 --> Severity: Warning --> The use statement with non-compound name 'Exception' has no effect C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 25
ERROR - 2021-06-28 10:01:08 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:01:42 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:01:55 --> Severity: Warning --> The use statement with non-compound name 'Exception' has no effect C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 25
ERROR - 2021-06-28 10:01:55 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:03:12 --> Severity: error --> Exception: Class 'App\Libraries\GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 20
ERROR - 2021-06-28 10:03:13 --> Severity: error --> Exception: Class 'App\Libraries\GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 20
ERROR - 2021-06-28 10:03:14 --> Severity: error --> Exception: Class 'App\Libraries\GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 20
ERROR - 2021-06-28 10:03:14 --> Severity: error --> Exception: Class 'App\Libraries\GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 20
ERROR - 2021-06-28 10:03:20 --> Severity: Warning --> The use statement with non-compound name 'Exception' has no effect C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 25
ERROR - 2021-06-28 10:03:20 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:05:18 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:06:33 --> Severity: Notice --> Undefined variable: output C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 26
ERROR - 2021-06-28 10:06:33 --> Severity: error --> Exception: Call to undefined function view() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 109
ERROR - 2021-06-28 10:06:47 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:06:48 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:06:48 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:06:48 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:06:48 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:09:13 --> Severity: error --> Exception: Call to undefined method GroceryCrud::_initialize_helpers() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4442
ERROR - 2021-06-28 10:09:25 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:19 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:20 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:21 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:21 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:21 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:30 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:31 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:31 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:31 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:32 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:32 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:32 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:33 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:33 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:33 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:33 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:34 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:10:42 --> Severity: error --> Exception: Class 'GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 22
ERROR - 2021-06-28 10:10:42 --> Severity: error --> Exception: Class 'GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 22
ERROR - 2021-06-28 10:10:43 --> Severity: error --> Exception: Class 'GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 22
ERROR - 2021-06-28 10:10:43 --> Severity: error --> Exception: Class 'GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 22
ERROR - 2021-06-28 10:10:51 --> Severity: Notice --> Undefined variable: crud C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 24
ERROR - 2021-06-28 10:10:51 --> Severity: error --> Exception: Call to a member function setTable() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 24
ERROR - 2021-06-28 10:10:52 --> Severity: Notice --> Undefined variable: crud C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 24
ERROR - 2021-06-28 10:10:52 --> Severity: error --> Exception: Call to a member function setTable() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 24
ERROR - 2021-06-28 10:10:52 --> Severity: Notice --> Undefined variable: crud C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 24
ERROR - 2021-06-28 10:10:52 --> Severity: error --> Exception: Call to a member function setTable() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 24
ERROR - 2021-06-28 10:11:04 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:11:12 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:04 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:05 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:06 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:06 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:06 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:07 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:07 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:07 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:07 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:08 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:18 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:19 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:19 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:12:19 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:13:44 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:13:47 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:13:47 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-28 10:15:37 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\GroceryCrud.php 4384
ERROR - 2021-06-28 10:16:56 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:16:59 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:19 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:22 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:22 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:22 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:45 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:46 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:46 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:46 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:56 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:58 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:59 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:17:59 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:18:00 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:51 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:53 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:53 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:53 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:54 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:55 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:19:55 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:02 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:03 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:03 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:03 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:16 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:18 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:18 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:18 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:44 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:46 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:47 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:20:47 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:36 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:37 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:38 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:38 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:38 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:38 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:39 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:40 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:40 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:40 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:40 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:53 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:54 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:54 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:21:54 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:11 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:12 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:12 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:50 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:51 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:51 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:52 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:52 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:22:52 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:24:21 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:24:22 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:24:22 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:24:22 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:24:52 --> Severity: Warning --> The use statement with non-compound name 'Exception' has no effect C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 25
ERROR - 2021-06-28 10:24:52 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 34
ERROR - 2021-06-28 10:25:01 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 34
ERROR - 2021-06-28 10:25:33 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_field_upload() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 38
ERROR - 2021-06-28 10:25:39 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:25:50 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 34
ERROR - 2021-06-28 10:25:56 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:25:57 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:25:57 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:25:57 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:25:58 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:25:58 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:26:42 --> Severity: Notice --> Undefined variable: crud C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 34
ERROR - 2021-06-28 10:26:42 --> Severity: error --> Exception: Call to a member function set_relation() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 34
ERROR - 2021-06-28 10:27:18 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:27:35 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:27:37 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:27:37 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:27:37 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:07 --> Severity: Notice --> Undefined variable: crud C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:07 --> Severity: error --> Exception: Call to a member function set_relation() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:16 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:33 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:33 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:34 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:34 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:28:34 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_relation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:29:05 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_field_upload() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 39
ERROR - 2021-06-28 10:29:46 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:32:12 --> Severity: error --> Exception: Call to undefined method Kendaraan::_theme_view() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:32:25 --> Severity: error --> Exception: Call to undefined method Kendaraan::_theme_view() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:32:36 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:32:37 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:32:37 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:32:37 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:34:17 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:20 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:21 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:21 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:21 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:36 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:38 --> Non-existent class: GroceryCrud
ERROR - 2021-06-28 10:34:54 --> Severity: Warning --> The use statement with non-compound name 'Exception' has no effect C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 25
ERROR - 2021-06-28 10:34:54 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:35:02 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:35:51 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:53 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:53 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:53 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:53 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:53 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:54 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:35:54 --> Severity: error --> Exception: Call to undefined function helper() C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4384
ERROR - 2021-06-28 10:39:00 --> Severity: error --> Exception: Class 'Config\GroceryCrud' not found C:\xampp\htdocs\alter_private\sewamobil\application\libraries\groceryCrud.php 4392
ERROR - 2021-06-28 10:39:02 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:39:03 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:39:03 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:39:03 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:39:04 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:39:04 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:39:22 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_table() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 44
ERROR - 2021-06-28 10:39:27 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_subject() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 45
ERROR - 2021-06-28 10:39:33 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_language() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 46
ERROR - 2021-06-28 10:39:38 --> Severity: error --> Exception: Call to undefined method GroceryCrud::set_theme() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Super.php 43
ERROR - 2021-06-28 10:43:03 --> Unable to load the requested class: GroceryCrud
ERROR - 2021-06-28 10:43:48 --> Severity: error --> Exception: Call to undefined method Grocery_CRUD::setRelation() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 35
ERROR - 2021-06-28 10:45:28 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:45:28 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:45:28 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:04 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:04 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:04 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:41 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:41 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:41 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:49 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:49 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:49 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:49 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:49 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:49:49 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:50:01 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:50:01 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:50:01 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:50:25 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:50:25 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:50:25 --> Severity: Notice --> Undefined index: form_upload_a_file C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4291
ERROR - 2021-06-28 10:54:19 --> Query error: Table 'alter_priv_sewa.produk' doesn't exist - Invalid query: SHOW COLUMNS FROM `produk`
ERROR - 2021-06-28 10:54:24 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 5236
ERROR - 2021-06-28 11:19:17 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 11:19:28 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 11:38:27 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 104
ERROR - 2021-06-28 11:54:17 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 11:58:48 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 301
ERROR - 2021-06-28 11:58:49 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 301
ERROR - 2021-06-28 11:58:50 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 301
ERROR - 2021-06-28 11:58:59 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 301
ERROR - 2021-06-28 12:34:01 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 12:35:45 --> Query error: Unknown column 'transaksi.id_transaksi' in 'on clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_user` IS NULL
ORDER BY `id` DESC
ERROR - 2021-06-28 12:35:48 --> Query error: Unknown column 'transaksi.id_transaksi' in 'on clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_user` IS NULL
ORDER BY `id` DESC
ERROR - 2021-06-28 12:36:04 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id`
WHERE `id_user` IS NULL
ORDER BY `id` DESC
ERROR - 2021-06-28 12:39:39 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 12:40:32 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 12:40:49 --> Query error: Column 'id_user' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `id_user`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `total_bayar`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`, `bank_tujuan`, `status_pembayaran`, `status_booking`) VALUES ('39', NULL, '20210628587', '2021-06-28 12:40:49', '350000', 700753, 'Dengan Driver', '2021-07-01', '2021-07-03', '00:00:00', 'BNI', 'Menunggu Pembayaran', 'Pending')
ERROR - 2021-06-28 12:43:09 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 12:46:49 --> Query error: Unknown column 'id_pembeli' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` IS NULL
ORDER BY `id_transaksi` DESC
ERROR - 2021-06-28 12:47:50 --> 404 Page Not Found: Index/product
ERROR - 2021-06-28 12:52:04 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 12:56:07 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 29
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 30
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 45
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 46
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 57
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 60
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 63
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 66
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 81
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 92
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 95
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 103
ERROR - 2021-06-28 12:56:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 106
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 29
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 30
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 45
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 46
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 57
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 60
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 63
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 66
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 81
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 92
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 95
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 103
ERROR - 2021-06-28 12:57:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 106
ERROR - 2021-06-28 13:00:19 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 13:03:15 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 13:08:43 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 13:13:17 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 13:15:39 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 15:14:30 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 29
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 30
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 45
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 46
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 57
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 60
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 63
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 66
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 81
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 92
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 95
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 103
ERROR - 2021-06-28 15:28:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_booking.php 106
ERROR - 2021-06-28 15:35:36 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 32
ERROR - 2021-06-28 15:40:50 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 319
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 32
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 36
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 40
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 44
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 48
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 52
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$tgl_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 64
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$total_bayar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 70
ERROR - 2021-06-28 15:41:17 --> Severity: Notice --> Undefined property: stdClass::$tgl_konfirmasi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 78
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 32
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 36
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 40
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 44
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 48
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 52
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$tgl_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 64
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$total_bayar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 70
ERROR - 2021-06-28 15:41:42 --> Severity: Notice --> Undefined property: stdClass::$tgl_konfirmasi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 78
ERROR - 2021-06-28 15:42:01 --> Severity: Notice --> Undefined property: stdClass::$tgl_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 64
ERROR - 2021-06-28 15:42:01 --> Severity: Notice --> Undefined property: stdClass::$total_bayar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 70
ERROR - 2021-06-28 15:42:01 --> Severity: Notice --> Undefined property: stdClass::$tgl_konfirmasi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 78
ERROR - 2021-06-28 15:42:35 --> Severity: Notice --> Undefined property: stdClass::$tgl_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 64
ERROR - 2021-06-28 15:42:35 --> Severity: Notice --> Undefined property: stdClass::$total_bayar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 70
ERROR - 2021-06-28 15:42:52 --> Severity: Notice --> Undefined property: stdClass::$total_bayar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 70
ERROR - 2021-06-28 15:45:56 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: SELECT *
FROM `transaksi`
JOIN `pembeli` ON `transaksi`.`id_pembeli`=`pembeli`.`id_pembeli`
WHERE `id_transaksi` = '37'
ERROR - 2021-06-28 15:52:30 --> Query error: Unknown column 'id_transaksi' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
WHERE `id_transaksi` = '37'
ERROR - 2021-06-28 15:52:54 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: SELECT *
FROM `transaksi`
JOIN `pembeli` ON `transaksi`.`id_pembeli`=`pembeli`.`id_pembeli`
WHERE `id_transaksi` = '37'
ERROR - 2021-06-28 15:54:53 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: SELECT *
FROM `transaksi`
JOIN `pembeli` ON `transaksi`.`id_pembeli`=`pembeli`.`id_pembeli`
WHERE `id_transaksi` = '37'
ERROR - 2021-06-28 16:00:15 --> 404 Page Not Found: Pensanan/invoice
ERROR - 2021-06-28 16:01:59 --> 404 Page Not Found: Pensanan/invoice
ERROR - 2021-06-28 16:04:14 --> 404 Page Not Found: Pensanan/invoice
ERROR - 2021-06-28 16:04:14 --> 404 Page Not Found: Pensanan/invoice
ERROR - 2021-06-28 16:04:32 --> 404 Page Not Found: Pensanan/invoice
ERROR - 2021-06-28 16:04:37 --> Severity: Notice --> Undefined variable: produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 58
ERROR - 2021-06-28 16:04:37 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 58
ERROR - 2021-06-28 16:10:02 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Pesanan.php 28
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 60
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 60
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: kota C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 77
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 77
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 60
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 60
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 78
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:10:44 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 60
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 60
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 78
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:11:14 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 78
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:14:36 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 78
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:15:28 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 61
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 62
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 63
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 78
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:18:55 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:19:49 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:24:58 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:29:14 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:29:37 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:32:26 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 16:33:08 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 67
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 68
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 82
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 17:54:50 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 86
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 64
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 80
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:56:35 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 80
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:57:11 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 65
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 66
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 80
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:57:42 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 84
ERROR - 2021-06-28 17:58:08 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 77
ERROR - 2021-06-28 17:58:08 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 81
ERROR - 2021-06-28 17:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 81
ERROR - 2021-06-28 17:58:08 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 81
ERROR - 2021-06-28 17:58:27 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 77
ERROR - 2021-06-28 17:58:27 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 81
ERROR - 2021-06-28 17:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 81
ERROR - 2021-06-28 17:58:27 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 81
ERROR - 2021-06-28 18:00:24 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 79
ERROR - 2021-06-28 18:00:24 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 83
ERROR - 2021-06-28 18:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 83
ERROR - 2021-06-28 18:00:24 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 83
ERROR - 2021-06-28 18:02:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 135
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 140
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 144
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 148
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 152
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$status_pembayaran C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 156
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$kode_booking C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 161
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 170
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:21:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Undefined property: stdClass::$kode_booking C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 161
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 170
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:21:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 170
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:22:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:22:43 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:22:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 199
ERROR - 2021-06-28 18:22:43 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:22:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 205
ERROR - 2021-06-28 18:22:43 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:22:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 229
ERROR - 2021-06-28 18:23:49 --> Query error: Unknown column 'transaksi.kode_unik' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `merk`.`nama` as `nama_merk`, `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jumlah_hari`, `transaksi`.`total_bayar`, `transaksi`.`harga_layanan`, `transaksi`.`status_pembayaran`, `transaksi`.`kode_booking`, `kendaraan`.`gambar`, `transaksi`.`kode_unik`
FROM `transaksi`
JOIN `kendaraan` ON `transaksi`.`id_kendaraan` = `kendaraan`.`id`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `transaksi`.`id` = '37'
ERROR - 2021-06-28 18:26:55 --> Query error: Unknown column 'transaksi.kode_unik' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `merk`.`nama` as `nama_merk`, `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jumlah_hari`, `transaksi`.`total_bayar`, `transaksi`.`harga_layanan`, `transaksi`.`status_pembayaran`, `transaksi`.`kode_booking`, `kendaraan`.`gambar`, `transaksi`.`kode_unik`
FROM `transaksi`
JOIN `kendaraan` ON `transaksi`.`id_kendaraan` = `kendaraan`.`id`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `transaksi`.`id` = '37'
ERROR - 2021-06-28 18:26:58 --> Query error: Unknown column 'transaksi.kode_unik' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `merk`.`nama` as `nama_merk`, `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jumlah_hari`, `transaksi`.`total_bayar`, `transaksi`.`harga_layanan`, `transaksi`.`status_pembayaran`, `transaksi`.`kode_booking`, `kendaraan`.`gambar`, `transaksi`.`kode_unik`
FROM `transaksi`
JOIN `kendaraan` ON `transaksi`.`id_kendaraan` = `kendaraan`.`id`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `transaksi`.`id` = '37'
ERROR - 2021-06-28 18:26:58 --> Query error: Unknown column 'transaksi.kode_unik' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `merk`.`nama` as `nama_merk`, `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jumlah_hari`, `transaksi`.`total_bayar`, `transaksi`.`harga_layanan`, `transaksi`.`status_pembayaran`, `transaksi`.`kode_booking`, `kendaraan`.`gambar`, `transaksi`.`kode_unik`
FROM `transaksi`
JOIN `kendaraan` ON `transaksi`.`id_kendaraan` = `kendaraan`.`id`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `transaksi`.`id` = '37'
ERROR - 2021-06-28 18:27:05 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 207
ERROR - 2021-06-28 18:27:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 207
ERROR - 2021-06-28 18:27:05 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 231
ERROR - 2021-06-28 18:27:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 231
ERROR - 2021-06-28 18:27:40 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 231
ERROR - 2021-06-28 18:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 231
ERROR - 2021-06-28 18:28:17 --> Severity: Notice --> Undefined property: stdClass::$id_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 232
ERROR - 2021-06-28 18:28:54 --> Severity: Notice --> Undefined property: stdClass::$id_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 232
ERROR - 2021-06-28 18:29:20 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:49:57 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:50:22 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:51:22 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:53:21 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:53:45 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 18:54:58 --> Severity: Notice --> Undefined property: stdClass::$jam_mulai C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 189
ERROR - 2021-06-28 18:57:43 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 19:01:10 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 19:10:02 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 19:10:40 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 19:12:00 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 19:25:46 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 19:29:37 --> Query error: Unknown column 'id_transaksi' in 'where clause' - Invalid query: SELECT *
FROM `transaksi`
WHERE `id_transaksi` = '37'
ERROR - 2021-06-28 19:31:59 --> Severity: Notice --> Undefined property: stdClass::$id_transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 14
ERROR - 2021-06-28 19:33:04 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 14
ERROR - 2021-06-28 19:33:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 14
ERROR - 2021-06-28 19:33:04 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 21
ERROR - 2021-06-28 19:33:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 21
ERROR - 2021-06-28 19:33:23 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 14
ERROR - 2021-06-28 19:33:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 14
ERROR - 2021-06-28 19:33:23 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 21
ERROR - 2021-06-28 19:33:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 21
ERROR - 2021-06-28 19:34:13 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 21
ERROR - 2021-06-28 19:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_konfirmasi.php 21
ERROR - 2021-06-28 19:40:39 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: SELECT *
FROM `transaksi`
JOIN `pembeli` ON `transaksi`.`id_pembeli`=`pembeli`.`id_pembeli`
WHERE `id_transaksi` = '37'
ERROR - 2021-06-28 20:02:45 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 20:03:16 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-28 20:03:22 --> 404 Page Not Found: Assets/front
