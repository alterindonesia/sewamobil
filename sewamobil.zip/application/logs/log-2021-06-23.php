<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-23 08:11:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 90
ERROR - 2021-06-23 08:11:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 91
ERROR - 2021-06-23 08:11:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 95
ERROR - 2021-06-23 08:12:32 --> Query error: Table 'alter_priv_sewa.konfirmasi' doesn't exist - Invalid query: SELECT *
FROM `konfirmasi`
ERROR - 2021-06-23 08:12:32 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:12:32 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:12:48 --> Query error: Table 'alter_priv_sewa.konfirmasi' doesn't exist - Invalid query: SELECT *
FROM `konfirmasi`
ERROR - 2021-06-23 08:12:48 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:12:48 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:13:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 90
ERROR - 2021-06-23 08:13:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 91
ERROR - 2021-06-23 08:13:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 95
ERROR - 2021-06-23 08:13:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 90
ERROR - 2021-06-23 08:13:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 91
ERROR - 2021-06-23 08:13:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 95
ERROR - 2021-06-23 08:14:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 90
ERROR - 2021-06-23 08:14:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 91
ERROR - 2021-06-23 08:14:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 95
ERROR - 2021-06-23 08:45:42 --> Query error: Table 'alter_priv_sewa.kategori' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-23 08:45:42 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:42 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:50 --> Query error: Table 'alter_priv_sewa.kategori' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-23 08:45:50 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:51 --> Query error: Table 'alter_priv_sewa.kategori' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-23 08:45:51 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:51 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:51 --> Query error: Table 'alter_priv_sewa.kategori' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-23 08:45:51 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-23 08:45:51 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
