<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-29 06:16:56 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 06:17:03 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 06:17:33 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 06:17:36 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 06:23:30 --> 404 Page Not Found: Index/product
ERROR - 2021-06-29 06:32:34 --> 404 Page Not Found: User/profil
ERROR - 2021-06-29 06:33:47 --> 404 Page Not Found: User/profil
ERROR - 2021-06-29 06:47:06 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 06:51:24 --> Query error: Unknown column 'lama_hari' in 'field list' - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `id_user`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `total_bayar`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`, `lama_hari`, `bank_tujuan`, `status_pembayaran`, `status_booking`) VALUES ('37', '10', '20210629198', '2021-06-29 06:51:24', '250000', 500724, 'Tanpa Driver', '2021-06-29', '2021-07-01', '18:00:00', 2, 'MANDIRI', 'Menunggu Pembayaran', 'Pending')
ERROR - 2021-06-29 07:12:36 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 07:14:34 --> Severity: Notice --> Undefined property: stdClass::$tgl_mulai C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 88
ERROR - 2021-06-29 07:14:34 --> Severity: Notice --> Undefined property: stdClass::$tgl_mulai C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_pesanan.php 88
ERROR - 2021-06-29 07:15:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jam_mulai`
FROM `transaksi`
' at line 1 - Invalid query: SELECT `transaksi`.`id` as `id_transaksi`, `transaksi`.`kode_booking`, `transaksi`.`status_pembayaran`, `transaksi`.`tgl_konfirmasi`, `transaksi`.`tgl_transaksi`, `transaksi`.`total_bayar;` `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jam_mulai`
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksii` = `transaksi`.`id`
WHERE `id_user` = '10'
ORDER BY `transaksi`.`id` DESC
ERROR - 2021-06-29 08:23:47 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 08:25:24 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 08:28:36 --> 404 Page Not Found: User/profil
ERROR - 2021-06-29 08:29:06 --> 404 Page Not Found: User/profil
ERROR - 2021-06-29 08:40:20 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 08:42:39 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 08:42:47 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 08:47:08 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 69
ERROR - 2021-06-29 09:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 75
ERROR - 2021-06-29 09:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 81
ERROR - 2021-06-29 09:26:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 72
ERROR - 2021-06-29 09:33:49 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:34:17 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:35:03 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:35:52 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:36:25 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:40:10 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 09:41:11 --> Severity: Notice --> Undefined property: stdClass::$no_telepon C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 107
ERROR - 2021-06-29 09:48:52 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 10:10:49 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Akun.php 31
ERROR - 2021-06-29 10:31:07 --> Severity: Notice --> Undefined variable: upload C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Akun.php 38
ERROR - 2021-06-29 10:40:15 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:17 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:21 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:29 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:36 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:41 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:43 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:40:48 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:41:07 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:41:12 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:41:34 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:41:45 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:42:40 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:42:44 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:42:51 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:43:31 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:44:16 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:44:33 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:44:37 --> Severity: error --> Exception: Call to undefined function form_open_multipart() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_akun.php 158
ERROR - 2021-06-29 10:45:53 --> 404 Page Not Found: Akun/ktp
ERROR - 2021-06-29 16:47:38 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Akun.php 57
ERROR - 2021-06-29 17:44:41 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Akun.php 26
ERROR - 2021-06-29 17:56:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:56:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:56:56 --> Unable to connect to the database
ERROR - 2021-06-29 17:56:56 --> Unable to connect to the database
ERROR - 2021-06-29 17:57:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:57:52 --> Unable to connect to the database
ERROR - 2021-06-29 17:57:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:57:58 --> Unable to connect to the database
ERROR - 2021-06-29 17:58:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:58:09 --> Unable to connect to the database
ERROR - 2021-06-29 17:58:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:58:31 --> Unable to connect to the database
ERROR - 2021-06-29 17:58:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:58:31 --> Unable to connect to the database
ERROR - 2021-06-29 17:58:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:58:34 --> Unable to connect to the database
ERROR - 2021-06-29 17:58:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:58:37 --> Unable to connect to the database
ERROR - 2021-06-29 17:58:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 17:58:40 --> Unable to connect to the database
ERROR - 2021-06-29 18:13:44 --> Severity: Notice --> Undefined index: userfile C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Akun.php 29
ERROR - 2021-06-29 19:53:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 19:53:23 --> Unable to connect to the database
ERROR - 2021-06-29 19:53:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 19:53:27 --> Unable to connect to the database
ERROR - 2021-06-29 19:53:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-06-29 19:53:31 --> Unable to connect to the database
ERROR - 2021-06-29 19:55:02 --> 404 Page Not Found: Akun/upload_ktp
ERROR - 2021-06-29 22:45:51 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-29 22:45:57 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-29 23:04:04 --> 404 Page Not Found: Akun/upload_ktp
ERROR - 2021-06-29 23:04:12 --> 404 Page Not Found: Akun/upload_ktp
ERROR - 2021-06-29 23:05:04 --> 404 Page Not Found: Akun/upload_ktp
ERROR - 2021-06-29 23:11:32 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 23:11:35 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 23:31:21 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-29 23:31:51 --> 404 Page Not Found: Assets/front
