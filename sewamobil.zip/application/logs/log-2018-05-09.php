<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-09 05:23:41 --> An invalid name was submitted as the product name: Intelijen & Pilkada The name can only contain alpha-numeric characters, dashes, underscores, colons, and spaces
ERROR - 2018-05-09 05:24:04 --> An invalid name was submitted as the product name: Intelijen & Pilkada The name can only contain alpha-numeric characters, dashes, underscores, colons, and spaces
ERROR - 2018-05-09 05:25:08 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 123
