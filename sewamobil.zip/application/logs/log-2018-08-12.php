<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-12 01:04:20 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\alter_private\dinda\application\views\front\v_invoice.php 64
ERROR - 2018-08-12 01:06:59 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
ERROR - 2018-08-12 01:07:00 --> Severity: Notice --> Undefined property: stdClass::$Keterangan_minus C:\xampp\htdocs\alter_private\dinda\application\views\front\v_invoice.php 64
ERROR - 2018-08-12 01:14:44 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\dinda\application\views\front\v_invoice.php 82
ERROR - 2018-08-12 01:14:44 --> Severity: Notice --> Undefined variable: ongkir C:\xampp\htdocs\alter_private\dinda\application\views\front\v_invoice.php 86
ERROR - 2018-08-12 01:20:47 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
ERROR - 2018-08-12 01:21:37 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
ERROR - 2018-08-12 01:22:36 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
ERROR - 2018-08-12 01:32:13 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-08-12 01:42:22 --> Query error: Unknown column 'produk_rekomendasi.id_kategori' in 'on clause' - Invalid query: SELECT `produk_rekomendasi`.*, j7d0afa90.nama_kategori AS s7d0afa90
FROM `produk_rekomendasi`
LEFT JOIN `kategori` as `j7d0afa90` ON `j7d0afa90`.`id_kategori` = `produk_rekomendasi`.`id_kategori`
 LIMIT 10
ERROR - 2018-08-12 04:40:14 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-12 04:42:29 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-12 04:55:04 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-12 05:05:08 --> 404 Page Not Found: Assets/front
