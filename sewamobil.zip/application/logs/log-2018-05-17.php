<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-17 04:59:42 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\admin\sb_admin\page\detailtransaksi.php 61
ERROR - 2018-05-17 04:59:42 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\admin\sb_admin\page\detailtransaksi.php 64
ERROR - 2018-05-17 04:59:42 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\admin\sb_admin\page\detailtransaksi.php 64
ERROR - 2018-05-17 05:00:43 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\admin\sb_admin\page\detailtransaksi.php 62
ERROR - 2018-05-17 05:00:43 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\admin\sb_admin\page\detailtransaksi.php 62
ERROR - 2018-05-17 05:09:07 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:11:13 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:11:32 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:12:24 --> Severity: Warning --> Missing argument 1 for Konfirmasi::index(), called in C:\xampp\htdocs\alter_private\maya\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 11
ERROR - 2018-05-17 05:12:24 --> Severity: Notice --> Undefined variable: city C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 34
ERROR - 2018-05-17 05:12:24 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 34
ERROR - 2018-05-17 05:13:04 --> Severity: Warning --> Missing argument 1 for Konfirmasi::index(), called in C:\xampp\htdocs\alter_private\maya\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 11
ERROR - 2018-05-17 05:13:04 --> Severity: Notice --> Undefined variable: city C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 34
ERROR - 2018-05-17 05:13:04 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 34
ERROR - 2018-05-17 05:13:10 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:13:36 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:22 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:22 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:23 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:23 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:23 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:23 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:24 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:24 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:30 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:31 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:31 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:32 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:32 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:18:44 --> Severity: Warning --> Missing argument 1 for Konfirmasi::index(), called in C:\xampp\htdocs\alter_private\maya\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 11
ERROR - 2018-05-17 05:18:44 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 13
ERROR - 2018-05-17 05:18:44 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::row() C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 14
ERROR - 2018-05-17 05:19:51 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:19:53 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:19:54 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:19:54 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:20:33 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:20:33 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:21:15 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:21:15 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:21:15 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:18 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:19 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:20 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:20 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:48 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:49 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:49 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:49 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:50 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 17
ERROR - 2018-05-17 05:22:56 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:56 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:57 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:22:57 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:23:01 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:23:27 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:23:27 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:23:27 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:24:04 --> 404 Page Not Found: Konfirmasi/7
ERROR - 2018-05-17 05:38:52 --> Query error: Unknown column 'bank' in 'field list' - Invalid query: INSERT INTO `komentar` (`bank`) VALUES ('BCA')
ERROR - 2018-05-17 05:39:11 --> Query error: Unknown column 'bank' in 'field list' - Invalid query: INSERT INTO `konfirmasi` (`bank`) VALUES ('MANDIRI')
ERROR - 2018-05-17 05:55:47 --> Query error: Table 'alter_priv_maya.konfimasi' doesn't exist - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfimasi` ON `konfirmasi`.`id_transaksi` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` = '10'
ERROR - 2018-05-17 05:56:04 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 56
ERROR - 2018-05-17 05:59:08 --> Query error: Unknown column 'konfirmasi.id_transaksi' in 'on clause' - Invalid query: SELECT *
FROM `transaksi`
LEFT JOIN `konfirmasi` ON `konfirmasi`.`id_transaksi` = `transaksi`.`id_transaksi`
WHERE `id_pembeli` = '10'
ERROR - 2018-05-17 05:59:21 --> Severity: error --> Exception: syntax error, unexpected '}', expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 58
ERROR - 2018-05-17 06:05:57 --> 404 Page Not Found: admin/Konfirmasi/index
ERROR - 2018-05-17 06:06:40 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\xampp\htdocs\alter_private\maya\application\libraries\Grocery_CRUD.php 4945
ERROR - 2018-05-17 06:07:44 --> Severity: Notice --> Undefined property: stdClass::$status_kofirmasi C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 57
ERROR - 2018-05-17 09:54:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-17 09:54:16 --> Unable to connect to the database
ERROR - 2018-05-17 09:54:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-17 09:54:20 --> Unable to connect to the database
ERROR - 2018-05-17 09:54:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-17 09:54:22 --> Unable to connect to the database
ERROR - 2018-05-17 09:54:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-17 09:54:25 --> Unable to connect to the database
ERROR - 2018-05-17 09:54:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-17 09:54:32 --> Unable to connect to the database
ERROR - 2018-05-17 09:54:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-17 09:54:53 --> Unable to connect to the database
