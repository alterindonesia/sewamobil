<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-11 12:02:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-08-11 12:02:36 --> Unable to connect to the database
ERROR - 2018-08-11 12:53:52 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 12:54:18 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 12:54:29 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 12:54:51 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 12:55:41 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 12:56:10 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 13:25:55 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 13:25:58 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 13:26:36 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 13:32:45 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 13:46:00 --> 404 Page Not Found: Index/register
ERROR - 2018-08-11 13:46:11 --> 404 Page Not Found: Index/register
ERROR - 2018-08-11 13:46:15 --> 404 Page Not Found: Index/register
ERROR - 2018-08-11 13:46:35 --> 404 Page Not Found: Index/register
ERROR - 2018-08-11 13:46:39 --> 404 Page Not Found: Index/register
ERROR - 2018-08-11 13:47:03 --> 404 Page Not Found: Index/register
ERROR - 2018-08-11 18:39:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Only one usage of each socket address (protocol/network address/port) is normally permitted.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-08-11 18:39:58 --> Unable to connect to the database
ERROR - 2018-08-11 18:43:39 --> 404 Page Not Found: Assets/front
ERROR - 2018-08-11 18:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 63
ERROR - 2018-08-11 18:58:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 63
ERROR - 2018-08-11 18:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 61
ERROR - 2018-08-11 18:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 63
ERROR - 2018-08-11 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 61
ERROR - 2018-08-11 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 63
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 63
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 64
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 65
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 66
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 67
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 68
ERROR - 2018-08-11 19:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\dinda\application\views\front\v_checkout.php 71
ERROR - 2018-08-11 19:23:43 --> Query error: Column 'keterangan' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (1, '40', 100000, 1, 100000, NULL)
ERROR - 2018-08-11 19:26:54 --> Severity: Notice --> Undefined index: keterangan_minus C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 132
ERROR - 2018-08-11 19:26:54 --> Severity: Notice --> Undefined index: besar_minus C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 133
ERROR - 2018-08-11 19:26:54 --> Query error: Column 'keterangan_minus' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (2, '40', 100000, NULL, NULL, 1, 100000, NULL)
ERROR - 2018-08-11 19:27:18 --> Severity: Notice --> Undefined index: keterangan_minus C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 132
ERROR - 2018-08-11 19:27:18 --> Severity: Notice --> Undefined index: besar_minus C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 133
ERROR - 2018-08-11 19:27:18 --> Query error: Column 'keterangan_minus' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (3, '40', 100000, NULL, NULL, 1, 100000, NULL)
ERROR - 2018-08-11 19:28:19 --> Query error: Column 'keterangan' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (4, '37', 100000, 'minus', '0.25', 2, 200000, NULL)
ERROR - 2018-08-11 19:29:14 --> Query error: Column 'keterangan' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (5, '37', 100000, 'minus', '0.25', 2, 200000, NULL)
ERROR - 2018-08-11 19:30:22 --> Query error: Column 'keterangan' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (6, '37', 100000, 'minus', '0.25', 2, 200000, NULL)
ERROR - 2018-08-11 19:30:40 --> Query error: Column 'keterangan' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (7, '37', 100000, 'minus', '0.25', 2, 200000, NULL)
ERROR - 2018-08-11 19:32:12 --> Query error: Column 'keterangan' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (8, '37', 100000, 'minus', '0.25', 2, 200000, NULL)
ERROR - 2018-08-11 19:35:51 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
ERROR - 2018-08-11 19:42:26 --> 404 Page Not Found: Indexinvoice/1
