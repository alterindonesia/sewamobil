<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-09 11:21:40 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-09 11:21:45 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-09 11:22:15 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-09 11:22:28 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-07-09 11:22:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-09 11:23:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-09 11:23:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-09 11:24:43 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-09 11:24:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-09 11:26:37 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-09 11:38:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-09 11:38:26 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-09 11:38:44 --> 404 Page Not Found: Assets/front
