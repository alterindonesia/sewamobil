<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-07 06:36:23 --> 404 Page Not Found: Assets/front
