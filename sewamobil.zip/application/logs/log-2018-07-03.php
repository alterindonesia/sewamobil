<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-03 08:05:22 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:05:23 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:30:11 --> Severity: Notice --> Undefined index: transaksi C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:30:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:34:48 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:35:13 --> Severity: Notice --> Undefined index: transaksi C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:35:13 --> Severity: Notice --> Undefined variable: produk C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:35:13 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:36:51 --> Severity: Notice --> Undefined index: transaksi C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:36:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:36:51 --> Severity: Notice --> Undefined variable: produk C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:36:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:36:51 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:36:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:37:18 --> Severity: Notice --> Undefined index: transaksi C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:37:18 --> Severity: Notice --> Undefined variable: produk C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:37:18 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:38:28 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:38:37 --> Severity: Notice --> Undefined index: transaksi C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 29
ERROR - 2018-07-03 08:38:37 --> Severity: Notice --> Undefined variable: produk C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:38:37 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:40:25 --> An invalid name was submitted as the product name: Intelijen & Pilkada The name can only contain alpha-numeric characters, dashes, underscores, colons, and spaces
ERROR - 2018-07-03 08:40:45 --> Severity: Notice --> Undefined variable: produk C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:40:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:40:45 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:40:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 35
ERROR - 2018-07-03 08:41:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 36
ERROR - 2018-07-03 08:41:14 --> Severity: Notice --> Undefined variable: key C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 36
ERROR - 2018-07-03 08:41:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 36
ERROR - 2018-07-03 08:43:03 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:43:14 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `produk`
WHERE `id` = '34'
ERROR - 2018-07-03 08:43:50 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `produk`
WHERE `id` = '34'
ERROR - 2018-07-03 08:43:54 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `produk`
WHERE `id` = '34'
ERROR - 2018-07-03 08:44:33 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:44:42 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `produk`
WHERE `id` = '31'
ERROR - 2018-07-03 08:47:02 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 08:47:02 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 09:20:51 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
ERROR - 2018-07-03 09:23:31 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
