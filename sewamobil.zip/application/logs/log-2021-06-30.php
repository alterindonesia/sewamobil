<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-30 09:56:06 --> 404 Page Not Found: Akun/simpan_ktp
ERROR - 2021-06-30 10:00:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:03:25 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:04:49 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:05:32 --> 404 Page Not Found: admin/Merk/index
ERROR - 2021-06-30 10:05:39 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:15:32 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:16:56 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:16:59 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:18:27 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:18:45 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:18:46 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:18:46 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:18:46 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:19:02 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:19:47 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:19:50 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:20:14 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:20:15 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:20:15 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:21:21 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-30 10:21:23 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-30 10:21:24 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-30 10:21:24 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-30 10:21:24 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-30 10:21:44 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:22:11 --> 404 Page Not Found: admin/Merk/index
ERROR - 2021-06-30 10:22:15 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:22:27 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:23:55 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:24:22 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 10:25:00 --> 404 Page Not Found: admin/Kendaraan/mobil
ERROR - 2021-06-30 10:26:22 --> 404 Page Not Found: admin/Kendaraan/mobil
ERROR - 2021-06-30 10:26:33 --> 404 Page Not Found: admin/Kendaraan/mobil
ERROR - 2021-06-30 10:26:35 --> 404 Page Not Found: admin/Kendaraan/mobil
ERROR - 2021-06-30 10:26:35 --> 404 Page Not Found: admin/Kendaraan/mobil
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Css/plugins
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/jquery.js
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-06-30 10:26:38 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-06-30 10:27:11 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\sb_admin\v_sidebar.php 6
ERROR - 2021-06-30 10:27:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\sb_admin\v_sidebar.php 6
ERROR - 2021-06-30 10:27:11 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 58
ERROR - 2021-06-30 10:27:35 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\sb_admin\v_sidebar.php 6
ERROR - 2021-06-30 10:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\sb_admin\v_sidebar.php 6
ERROR - 2021-06-30 10:30:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 18
ERROR - 2021-06-30 10:30:15 --> Severity: error --> Exception: Call to undefined method Kendaraan::generateBreadcumbs() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 18
ERROR - 2021-06-30 10:30:55 --> Severity: error --> Exception: Call to undefined method Kendaraan::generateBreadcumbs() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 18
ERROR - 2021-06-30 10:42:17 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:46:51 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:46:51 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:35 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:35 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:40 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:40 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:49 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:49 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:57 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:57 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:58 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:58 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:58 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:47:58 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:48:03 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:48:03 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 10:52:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:52:57 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:52:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:54:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:54:17 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:54:17 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:55:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 10:56:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 71
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 72
ERROR - 2021-06-30 11:04:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 73
ERROR - 2021-06-30 11:04:46 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:05:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:06:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:06:18 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:06:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:07:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:07:13 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:07:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:08:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:08:41 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:08:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:09:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:09:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:22:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:22:38 --> 404 Page Not Found: Kendaraan/tambah
ERROR - 2021-06-30 11:23:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:23:25 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:27:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:28:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:29:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:30:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:31:21 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:32:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:33:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:33:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:33:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:33:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:34:13 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:35:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:35:12 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:36:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:38:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:39:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:41:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:41:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:48:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:50:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:51:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:51:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:51:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:52:02 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:53:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:53:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:53:57 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:53:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:53:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:54:18 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:54:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:54:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:54:20 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:54:32 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:54:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:55:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:55:28 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:55:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:55:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:56:03 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:56:04 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:56:12 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:56:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:56:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:57:27 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:57:41 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:57:46 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:58:05 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:58:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:59:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 11:59:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:01:28 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:01:34 --> Query error: Column 'bahan_bakar' cannot be null - Invalid query: INSERT INTO `kendaraan` (`id_merk`, `type`, `transmisi`, `jumlah_kursi`, `plat_nomor`, `kategori_plat`, `bahan_bakar`, `harga_include_driver`, `harga_exclude_driver`, `gambar`, `status`) VALUES ('1', '1', 'Pertamax', '7', 'B1234NMN', 'Ganjil', NULL, '1000000', '750000', 'mandiri1.jpg', 'Aktif')
ERROR - 2021-06-30 12:01:51 --> Query error: Column 'bahan_bakar' cannot be null - Invalid query: INSERT INTO `kendaraan` (`id_merk`, `type`, `transmisi`, `jumlah_kursi`, `plat_nomor`, `kategori_plat`, `bahan_bakar`, `harga_include_driver`, `harga_exclude_driver`, `gambar`, `status`) VALUES ('1', '1', 'Pertamax', '7', 'B1234NMN', 'Ganjil', NULL, '1000000', '750000', 'mandiri2.jpg', 'Aktif')
ERROR - 2021-06-30 12:01:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:02:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:02:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:02:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:02:46 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:04:05 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:05:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:05:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:24:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:24:57 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:57 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:57 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:24:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> Severity: Notice --> Undefined property: stdClass::$id_kendaraan C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_index.php 82
ERROR - 2021-06-30 12:25:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:26:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:26:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:26:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:27:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 96
ERROR - 2021-06-30 12:27:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:27:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:28:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_kursi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 119
ERROR - 2021-06-30 12:28:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:29:12 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:52:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 188
ERROR - 2021-06-30 12:52:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 188
ERROR - 2021-06-30 12:52:27 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:56:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 265
ERROR - 2021-06-30 12:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 265
ERROR - 2021-06-30 12:56:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:56:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 265
ERROR - 2021-06-30 12:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 265
ERROR - 2021-06-30 12:56:15 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:57:11 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\kendaraan\v_ubah.php 265
ERROR - 2021-06-30 12:57:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:57:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:57:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:57:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:57:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:58:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 12:58:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:00:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:00:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:01:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:01:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:01:47 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:02:25 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:02:27 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:02:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:02:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:04:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:04:32 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:04:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:08:32 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:08:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:08:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:09:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:09:17 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:09:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:10:20 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:10:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:10:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:10:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:10:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:11:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:11:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:13:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:13:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:13:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:09 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:15 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:46 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:15:47 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:16:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:16:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:15 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:21 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:18:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:20:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:25:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:27:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:32:01 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:42:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:43:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:43:50 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:45:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:45:50 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:55:31 --> Severity: error --> Exception: syntax error, unexpected ''status'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 97
ERROR - 2021-06-30 13:55:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:56:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:56:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:56:21 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:57:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:57:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:58:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 13:58:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:02:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:02:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:03:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:03:30 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:07:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:08:30 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:08:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:10:32 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:10:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:11:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:11:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:13:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:14:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:15:09 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:16:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:16:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:17:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:18:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:18:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:18:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:20:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:20:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:23:00 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 100
ERROR - 2021-06-30 14:23:42 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 111
ERROR - 2021-06-30 14:24:21 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:24:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 14:24:57 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:14:27 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:14:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:14:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:14:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 101
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 102
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 101
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 102
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 101
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 102
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:15:06 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:15:14 --> Severity: Notice --> Undefined property: Kendaraan::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 15:15:14 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Kendaraan.php 13
ERROR - 2021-06-30 15:15:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:18:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:22:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:22:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:23:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:23:47 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:23:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:24:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:15 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:25:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:26:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:26:53 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`status`, `kendaraan`.`file`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `merk`.`id` as `id_merk`, `merk`.`nama` as `nama_merk`, `kendaraan`.`plat_nomor`, `kendaraan`.`bahan_bakar`, `kendaraan`.`transmisi`, `kendaraan`.`kategori_plat`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`
FROM `kendaraan`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `id` = '50'
ORDER BY `tgl_input` DESC
ERROR - 2021-06-30 15:27:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 101
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 102
ERROR - 2021-06-30 15:28:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 101
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 102
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 101
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 102
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 138
ERROR - 2021-06-30 15:28:05 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 139
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 64
ERROR - 2021-06-30 15:29:04 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 65
ERROR - 2021-06-30 15:32:33 --> Query error: Unknown column 'kendaraan.gambar' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` <= '2021-07-01' and `tgl_mulai` <= '2021-07-01'
AND `tgl_akhir` >= '2021-07-01' and `tgl_akhir` >= '2021-07-01'
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-30 15:33:29 --> Query error: Unknown column 'kendaraan.gambar' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` <= '2021-07-01' and `tgl_mulai` <= '2021-07-01'
AND `tgl_akhir` >= '2021-07-01' and `tgl_akhir` >= '2021-07-01'
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-30 15:33:56 --> Query error: Unknown column 'kendaraan.gambar' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` <= '2021-07-01' and `tgl_mulai` <= '2021-07-01'
AND `tgl_akhir` >= '2021-07-01' and `tgl_akhir` >= '2021-07-01'
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-30 15:34:46 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:36:03 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:36:46 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:37:24 --> Query error: Unknown column 'kendaraan.gambar' in 'field list' - Invalid query: SELECT `kendaraan`.`type`, `merk`.`nama` as `nama_merk`, `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`jumlah_hari`, `transaksi`.`total_bayar`, `transaksi`.`harga_layanan`, `transaksi`.`status_pembayaran`, `transaksi`.`kode_booking`, `kendaraan`.`gambar`, `transaksi`.`id` as `id_transaksi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`kategori_plat`, `transaksi`.`layanan`, `transaksi`.`jam_mulai`, `transaksi`.`bank_tujuan`
FROM `transaksi`
JOIN `kendaraan` ON `transaksi`.`id_kendaraan` = `kendaraan`.`id`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `transaksi`.`id` = '39'
ERROR - 2021-06-30 15:37:52 --> Severity: Notice --> Undefined property: stdClass::$gambar C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 135
ERROR - 2021-06-30 15:39:11 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:43:26 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 85
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 99
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 104
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 108
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 112
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 116
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 120
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 125
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 135
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 139
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 139
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 143
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 146
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 149
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 152
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 155
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 167
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 168
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 174
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 175
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 181
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 187
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 194
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 201
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 207
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 214
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 221
ERROR - 2021-06-30 15:43:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 242
ERROR - 2021-06-30 15:44:34 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 85
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 99
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 104
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 108
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 112
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 116
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 120
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 125
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 135
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 139
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 139
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 143
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 146
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 149
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 152
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 155
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 167
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 168
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 174
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 175
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 181
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 187
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 194
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 201
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 207
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 214
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 221
ERROR - 2021-06-30 15:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 242
ERROR - 2021-06-30 15:44:56 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:45:39 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 85
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 99
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 104
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 108
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 112
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 116
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 120
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 125
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 135
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 139
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 139
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 143
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 146
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 149
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 152
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 155
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 167
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 168
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 174
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 175
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 181
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 187
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 194
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 201
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 207
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 214
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 221
ERROR - 2021-06-30 15:45:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_invoice.php 242
ERROR - 2021-06-30 15:51:17 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:52:22 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:52:32 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:53:00 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 15:53:12 --> 404 Page Not Found: Assets/uploads
ERROR - 2021-06-30 16:14:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:34:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:34:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:36:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:37:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:37:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:37:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:38:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:45:39 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:45:41 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:45:41 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:45:55 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:45:56 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:46:06 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:46:41 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:48:40 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:25 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:28 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:29 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:32 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:33 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:49 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:49:57 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:50:06 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:50:06 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:50:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:50:21 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:51:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:52:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:52:41 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:55:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:55:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:55:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 16:55:44 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:56:07 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:56:12 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:56:21 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:56:31 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:56:35 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:56:43 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:57:05 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:59:36 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:59:37 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:59:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 16:59:44 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:00:03 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:00:28 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:00:36 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 17:00:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:14:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:14:46 --> 404 Page Not Found: admin/Transaksi/index
ERROR - 2021-06-30 17:14:50 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:14:55 --> 404 Page Not Found: admin/Transaksi/index
ERROR - 2021-06-30 17:14:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:15:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:15:07 --> Query error: Unknown column 'transaksi.tgl_input' in 'field list' - Invalid query: SELECT `kendaraan`.`id` as `id_transaksi`, `kendaraan`.`type`, `user`.`nama` as `nama_user`, `kendaraan`.`id` as `id_kendaraan`, `merk`.`nama` as `nama_merk`, `transaksi`.`harga_layanan`, `transaksi`.`layanan`, `transaksi`.`tgl_mulai`, `transaksi`.`tgl_akhir`, `transaksi`.`tgl_input`, `transaksi`.`jam_mulai`, `transaksi`.`jumlah_hari`, `transaksi`.`total_bayar`, `transaksi`.`status_pembayaran`, `transaksi`.`status_booking`, `transaksi`.`bank_tujuan`, `transaksi`.`tgl_konfirmasi`, `transaksi`.`kode_booking`
FROM `transaksi`
JOIN `kendaraan` ON `kendaraan`.`id` = `transaksi`.`id_kendaraan`
JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
JOIN `user` ON `user`.`id` = `transaksi`.`id_user`
ORDER BY `tgl_input` DESC
ERROR - 2021-06-30 17:15:46 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:15:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:16:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:16:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:17:01 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:17:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:17:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:31:30 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 96
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 158
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 158
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 180
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 180
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 191
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 191
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 213
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 213
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 158
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 180
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 191
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 213
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 158
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 180
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 191
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 213
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 158
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 180
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 191
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 202
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 213
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:34:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 225
ERROR - 2021-06-30 17:35:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:35:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:36:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:36:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\transaksi\v_update.php 169
ERROR - 2021-06-30 17:41:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:44:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:45:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:45:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:46:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:46:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:46:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:47:04 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:47:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:47:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:47:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:47:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:48:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:48:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:48:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:48:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:49:04 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:49:14 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:49:17 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:49:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:49:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:49:47 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:51:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:51:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:52:11 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:52:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:52:30 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:52:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:52:54 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:52:58 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:53:01 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:53:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 17:54:14 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:55:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:55:52 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:56:05 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:56:06 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:56:20 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:58:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 17:58:47 --> Query error: Column 'id_kota' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES ('Lorem Ipsum', 'lorem@mail.com', 'asdf', '08121212', NULL, 'Jakarta Selatan')
ERROR - 2021-06-30 18:00:00 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:00:04 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:00:46 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:00:59 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:01:13 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:01:23 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:01:45 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:02:01 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:02:13 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 18:02:33 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:02:33 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:23 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:23 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:24 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:24 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:25 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:25 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:26 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:26 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:27 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:27 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 18:07:57 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 18:08:01 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 18:08:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 18:08:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 18:08:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 18:08:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 18:08:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:44:09 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 21:44:29 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 21:44:33 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 21:45:01 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:45:48 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 21:45:48 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 21:45:52 --> Severity: Notice --> Undefined property: Transaksi::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 21:45:52 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Transaksi.php 13
ERROR - 2021-06-30 21:46:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:46:18 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 21:46:20 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:46:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:46:24 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 21:46:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:46:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:47:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:48:30 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:48:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:52:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:52:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:53:04 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:53:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 21:59:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:00:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:00:48 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:01:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:01:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:02:04 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:02:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:02:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:02:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:03:16 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:03:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:03:29 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:03:32 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:03:36 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:03:39 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:03:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:04:02 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:04:05 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:04:15 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:04:16 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:04:37 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:04:40 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:04:46 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:05:10 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:05:10 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:05:17 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:05:17 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:05:18 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:05:18 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:01 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:01 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:06 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:06 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:06 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:06 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:07 --> Severity: Notice --> Undefined property: Booking::$master C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:08:07 --> Severity: error --> Exception: Call to a member function adminUrl() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Booking.php 13
ERROR - 2021-06-30 22:10:42 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\alter_private\sewamobil\application\controllers\admin\Dashboard.php 33
ERROR - 2021-06-30 22:11:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:11:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:11:17 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-06-30 22:11:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:12:46 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:14:09 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:14:25 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:15:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:19:02 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:19:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:19:49 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:20:15 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:20:56 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:21:51 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:22:08 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:22:22 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:22:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:22:47 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:23:06 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:23:13 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:24:24 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:24:41 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:24:43 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:24:46 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:25:08 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:25:56 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:26:07 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:26:34 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:26:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:27:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:27:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:29:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:29:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:29:53 --> 404 Page Not Found: admin/Penyewa/index
ERROR - 2021-06-30 22:37:03 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:37:13 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:37:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:37:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:38:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:40:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:40:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:40:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:40:57 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:41:09 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:41:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:42:18 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:43:17 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 22:51:29 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:55:03 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:55:25 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:55:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:56:00 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:56:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:56:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:57:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 22:57:17 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:00:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:00:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:00:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:03:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:04:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:05:12 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:05:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:05:39 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:05:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:05:43 --> 404 Page Not Found: admin/Merk/index
ERROR - 2021-06-30 23:05:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:06:21 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:06:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:06:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:06:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:07:05 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:07:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:07:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:07:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:08:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:08:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:08:57 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:09:09 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:09:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:10:02 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:10:20 --> 404 Page Not Found: admin/Kendaraan/detail
ERROR - 2021-06-30 23:20:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:20:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:22:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:23:35 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:23:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:24:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:24:42 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:24:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:25:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:25:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:26:37 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:27:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:27:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:27:44 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:30:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:30:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:32:11 --> Severity: Notice --> Undefined property: stdClass::$nama_penyewa C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\booking\v_detail.php 169
ERROR - 2021-06-30 23:41:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:42:09 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:43:38 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:43:51 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:45:03 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:45:06 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:45:13 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:45:27 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:45:28 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:45:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:46:04 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:46:08 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:46:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-30 23:46:20 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:46:29 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:46:37 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:03 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:17 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:21 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:34 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:46 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:50 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:47:55 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:22 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:24 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:28 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:40 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:44 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:57 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:48:59 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:49:03 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:49:30 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:49:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:49:52 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:50:07 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:50:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:50:36 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:50:48 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:52:20 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:52:23 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:52:25 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:52:27 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:53:33 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:53:39 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:53:56 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:54:02 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:54:30 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:55:25 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:55:48 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-30 23:55:52 --> 404 Page Not Found: Index/product
ERROR - 2021-06-30 23:55:55 --> 404 Page Not Found: Assets/front
