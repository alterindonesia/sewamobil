<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-18 05:52:19 --> Query error: Column 'besar_minus' cannot be null - Invalid query: INSERT INTO `transaksi_detail` (`id_transaksi`, `id_produk`, `harga`, `keterangan_minus`, `besar_minus`, `jumlah_produk`, `harga_total`, `keterangan`) VALUES (16, '37', 100000, 'normal', NULL, 1, 100000, '2')
ERROR - 2019-09-18 05:52:19 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2019-09-18 05:52:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
