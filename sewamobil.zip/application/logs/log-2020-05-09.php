<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-09 17:32:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-05-09 17:32:45 --> Unable to connect to the database
ERROR - 2020-05-09 17:32:45 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:32:45 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:32:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-05-09 17:32:50 --> Unable to connect to the database
ERROR - 2020-05-09 17:32:50 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:32:51 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:32:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-05-09 17:32:55 --> Unable to connect to the database
ERROR - 2020-05-09 17:32:55 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:32:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:33:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-05-09 17:33:00 --> Unable to connect to the database
ERROR - 2020-05-09 17:33:00 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:33:00 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:39:04 --> 404 Page Not Found: Assets/front
ERROR - 2020-05-09 17:39:04 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2020-05-09 17:39:04 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
