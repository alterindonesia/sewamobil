<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-03 21:22:48 --> 404 Page Not Found: Assets/front
