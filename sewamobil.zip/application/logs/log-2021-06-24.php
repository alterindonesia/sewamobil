	<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 98
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$id_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 08:55:15 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:02:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 177
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 177
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 94
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 95
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 104
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 106
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 123
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 124
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 133
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 135
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 152
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 153
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 162
ERROR - 2021-06-24 09:03:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 164
ERROR - 2021-06-24 09:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_index.php 177
ERROR - 2021-06-24 09:03:51 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4945
ERROR - 2021-06-24 09:03:51 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 09:03:51 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 09:24:46 --> Query error: Table 'alter_priv_sewa.produk' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-24 09:24:46 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:24:46 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:46:28 --> 404 Page Not Found: Kendaraan/detail
ERROR - 2021-06-24 09:46:28 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:46:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:47:25 --> 404 Page Not Found: Kendaraan/detail
ERROR - 2021-06-24 09:47:25 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:47:25 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:47:57 --> 404 Page Not Found: Kendaraan/detail
ERROR - 2021-06-24 09:47:57 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:47:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:48:21 --> 404 Page Not Found: Kendaraan/detail
ERROR - 2021-06-24 09:48:21 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:48:21 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:49:32 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:49:32 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:49:32 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:50:02 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:50:02 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:50:02 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:50:24 --> Query error: Table 'alter_priv_sewa.produk' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-24 09:50:24 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:50:24 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:13 --> Query error: Unknown column 'kendaraan.merk' in 'field list' - Invalid query: SELECT `kendaraan`.`merk`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:52:13 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:14 --> Query error: Unknown column 'kendaraan.merk' in 'field list' - Invalid query: SELECT `kendaraan`.`merk`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:52:14 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:15 --> Query error: Unknown column 'kendaraan.merk' in 'field list' - Invalid query: SELECT `kendaraan`.`merk`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:52:15 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:15 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:15 --> Query error: Unknown column 'kendaraan.merk' in 'field list' - Invalid query: SELECT `kendaraan`.`merk`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:52:15 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:15 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:15 --> Query error: Unknown column 'kendaraan.merk' in 'field list' - Invalid query: SELECT `kendaraan`.`merk`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:52:15 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:52:15 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:53:32 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:53:32 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:53:32 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:54:19 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:54:19 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:54:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:55:28 --> Query error: Unknown column 'id_kendaraan' in 'where clause' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id_kendaraan` = '37'
ERROR - 2021-06-24 09:55:28 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:55:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:55:58 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:55:58 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:55:58 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:57:39 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
JOIN `merk` ON `kendaraan`.`id_merk` = `merk`.`id`
WHERE `id` = '37'
ERROR - 2021-06-24 09:57:39 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 09:57:39 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:04:22 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:04:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:04:23 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:04:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:04:23 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:04:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:07:16 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4945
ERROR - 2021-06-24 10:07:16 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 10:07:16 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 10:10:11 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-24 10:10:11 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:10:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:10:46 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-24 10:10:46 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:10:46 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:11:22 --> 404 Page Not Found: admin/Kendaraan/index
ERROR - 2021-06-24 10:11:22 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 10:11:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:02:42 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4945
ERROR - 2021-06-24 11:02:42 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 11:02:42 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 11:03:49 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-24 11:03:49 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:03:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:04:05 --> 404 Page Not Found: Assets/admin
ERROR - 2021-06-24 11:04:05 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:04:05 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:17 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:17 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:17 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:21 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:21 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:21 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:23 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:23 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:23 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:24 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:24 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:24 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:25 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:25 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:25 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:26 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:26 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:27 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:27 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:28 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:20:28 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:20:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:23:57 --> Severity: Error --> Class 'CodeIgniter\Model' not found C:\xampp\htdocs\alter_private\sewamobil\application\models\Grocery_crud_model.php 32
ERROR - 2021-06-24 11:23:57 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_php.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 269
ERROR - 2021-06-24 11:23:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_php.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 269
ERROR - 2021-06-24 11:30:57 --> Non-existent class: Grocery_CRUD
ERROR - 2021-06-24 11:30:57 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:30:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:45:32 --> Query error: Table 'alter_priv_sewa.produk' doesn't exist - Invalid query: SHOW COLUMNS FROM `produk`
ERROR - 2021-06-24 11:45:32 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:45:32 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:45:42 --> Query error: Table 'alter_priv_sewa.produk' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `transaksi_detail` ON `transaksi_detail`.`id_produk`=`produk`.`id_produk`
WHERE `transaksi_detail`.`id_transaksi` = '15'
ERROR - 2021-06-24 11:45:42 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 11:45:42 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 12:10:38 --> Severity: error --> Exception: The table name does not exist. Please check you database and try again. C:\xampp\htdocs\alter_private\sewamobil\application\libraries\Grocery_CRUD.php 4945
ERROR - 2021-06-24 12:10:38 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 12:10:38 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 220
ERROR - 2021-06-24 12:14:25 --> Severity: Notice --> Undefined property: stdClass::$deskripsi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 54
ERROR - 2021-06-24 12:18:28 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-24 12:18:28 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-24 12:18:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
