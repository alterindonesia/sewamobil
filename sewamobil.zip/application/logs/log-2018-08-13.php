<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-13 12:15:39 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
ERROR - 2018-08-13 12:20:09 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\dinda\application\controllers\Index.php 140
