<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-27 05:55:29 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 05:55:29 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 05:55:29 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:05 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:05 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:05 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:06 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:06 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:06 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:07 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:07 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:07 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:07 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:07 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:07 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:08 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:08 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:08 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:08 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:04:08 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:04:08 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:07:15 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:07:15 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:07:15 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:08:35 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:08:35 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:08:35 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:08:46 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:08:46 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:08:46 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:09:08 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:09:08 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:09:08 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:57 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:10:57 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:57 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:58 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:10:58 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:58 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:58 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:10:58 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:58 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:59 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:10:59 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:59 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:10:59 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:10:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\sewamobil\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\sewamobil\system\core\Exceptions.php 182
ERROR - 2021-06-27 06:14:06 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: INSERT INTO `pembeli` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:14:33 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:14:37 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:15:24 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:16:28 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:17:09 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 06:19:44 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:22:38 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:27:31 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:27:58 --> Query error: Column 'nama' cannot be null - Invalid query: INSERT INTO `user` (`nama`, `email`, `password`, `no_telpon`, `id_kota`, `alamat`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-06-27 06:37:15 --> Query error: Table 'alter_priv_sewa.pembeli' doesn't exist - Invalid query: SELECT *
FROM `pembeli`
WHERE `email` = 'lorem@gmail.com'
AND `password` = 'asdf'
ERROR - 2021-06-27 06:41:31 --> Severity: Notice --> Undefined property: stdClass::$id_pembeli C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-27 06:41:33 --> Query error: Table 'alter_priv_sewa.konfirmasi' doesn't exist - Invalid query: SELECT *
FROM `konfirmasi`
ERROR - 2021-06-27 06:42:00 --> Query error: Table 'alter_priv_sewa.konfirmasi' doesn't exist - Invalid query: SELECT *
FROM `konfirmasi`
ERROR - 2021-06-27 06:44:11 --> Query error: Table 'alter_priv_sewa.produk' doesn't exist - Invalid query: SELECT *
FROM `produk`
JOIN `kategori` ON `produk`.`id_kategori`=`kategori`.`id_kategori`
ERROR - 2021-06-27 06:55:55 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 06:57:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 06:58:15 --> Severity: Notice --> Undefined property: stdClass::$transmisi C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 57
ERROR - 2021-06-27 07:26:00 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 07:28:25 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 07:35:27 --> Severity: Notice --> Undefined property: stdClass::$harga_include_friver C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 83
ERROR - 2021-06-27 07:35:27 --> Severity: Notice --> Undefined property: stdClass::$harga_exclude_friver C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 84
ERROR - 2021-06-27 07:35:51 --> Severity: Notice --> Undefined property: stdClass::$harga_include_friver C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 83
ERROR - 2021-06-27 07:35:51 --> Severity: Notice --> Undefined property: stdClass::$harga_exclude_friver C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 84
ERROR - 2021-06-27 07:40:39 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 07:41:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 08:41:05 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 08:42:14 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 09:26:39 --> 404 Page Not Found: Index/addcart
ERROR - 2021-06-27 09:27:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 136
ERROR - 2021-06-27 09:27:37 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:27:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:27:45 --> Severity: Notice --> Undefined property: stdClass::$id_pembeli C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-27 09:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 136
ERROR - 2021-06-27 09:27:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:29:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 136
ERROR - 2021-06-27 09:29:44 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:29:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 136
ERROR - 2021-06-27 09:30:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 136
ERROR - 2021-06-27 09:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 136
ERROR - 2021-06-27 09:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 144
ERROR - 2021-06-27 09:32:18 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 111
ERROR - 2021-06-27 09:32:20 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 111
ERROR - 2021-06-27 09:33:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 111
ERROR - 2021-06-27 09:33:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 111
ERROR - 2021-06-27 09:53:05 --> Severity: Compile Error --> Cannot redeclare Index::pesan() C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 108
ERROR - 2021-06-27 09:53:45 --> Query error: Unknown column 'id_kendaraan' in 'where clause' - Invalid query: SELECT *
FROM `kendaraan`
WHERE `id_kendaraan` IS NULL
ERROR - 2021-06-27 10:18:21 --> Severity: Notice --> Undefined property: Index::$inpu C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 107
ERROR - 2021-06-27 10:18:21 --> Severity: error --> Exception: Call to a member function post() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 107
ERROR - 2021-06-27 10:19:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 131
ERROR - 2021-06-27 10:19:22 --> Query error: Column 'harga_layanan' cannot be null - Invalid query: INSERT INTO `transaksi` (`kode_booking`, `tgl_transaksi`, `harga_layanan`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`) VALUES ('20210627701', '2021-06-27 10:19:22', NULL, NULL, '', '', NULL)
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 151
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 29
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 30
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 45
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 46
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 57
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 60
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 63
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 66
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 79
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 88
ERROR - 2021-06-27 10:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 92
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Index.php 151
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 29
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 30
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 45
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 46
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 57
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 60
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 63
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 66
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 79
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 88
ERROR - 2021-06-27 10:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_detail.php 92
ERROR - 2021-06-27 10:42:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 24
ERROR - 2021-06-27 10:42:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 25
ERROR - 2021-06-27 10:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 45
ERROR - 2021-06-27 10:42:34 --> Query error: Column 'harga_layanan' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`) VALUES ('37', '20210627695', '2021-06-27 10:42:34', NULL, 'Dengan Driver', '00:00:00', '00:00:00', '00:00:00')
ERROR - 2021-06-27 10:44:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 24
ERROR - 2021-06-27 10:44:18 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 25
ERROR - 2021-06-27 10:44:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 45
ERROR - 2021-06-27 10:44:18 --> Query error: Column 'harga_layanan' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`) VALUES ('37', '20210627360', '2021-06-27 10:44:18', NULL, 'Dengan Driver', '00:00:00', '00:00:00', '00:00:00')
ERROR - 2021-06-27 10:44:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 24
ERROR - 2021-06-27 10:44:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 25
ERROR - 2021-06-27 10:44:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 45
ERROR - 2021-06-27 10:44:21 --> Query error: Column 'harga_layanan' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`) VALUES ('37', '20210627704', '2021-06-27 10:44:21', NULL, 'Dengan Driver', '00:00:00', '00:00:00', '00:00:00')
ERROR - 2021-06-27 10:44:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 24
ERROR - 2021-06-27 10:44:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 25
ERROR - 2021-06-27 10:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 45
ERROR - 2021-06-27 10:44:32 --> Query error: Column 'harga_layanan' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`) VALUES ('37', '20210627391', '2021-06-27 10:44:32', NULL, 'Dengan Driver', '00:00:00', '00:00:00', '00:00:00')
ERROR - 2021-06-27 10:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 45
ERROR - 2021-06-27 10:46:25 --> Query error: Column 'harga_layanan' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_kendaraan`, `kode_booking`, `tgl_transaksi`, `harga_layanan`, `layanan`, `tgl_mulai`, `tgl_akhir`, `jam_mulai`) VALUES ('37', '20210627675', '2021-06-27 10:46:25', NULL, 'Dengan Driver', '2021-06-2700:00:00', '2021-06-2800:00:00', '00:00:00')
ERROR - 2021-06-27 10:59:52 --> Severity: Notice --> Undefined variable: tanggal C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 31
ERROR - 2021-06-27 12:44:07 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 12:48:32 --> 404 Page Not Found: Assets/front
ERROR - 2021-06-27 12:52:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 58
ERROR - 2021-06-27 12:52:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 58
ERROR - 2021-06-27 12:52:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 58
ERROR - 2021-06-27 12:52:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 58
ERROR - 2021-06-27 12:52:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 58
ERROR - 2021-06-27 12:52:50 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 58
ERROR - 2021-06-27 15:51:28 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 84
ERROR - 2021-06-27 15:57:08 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 90
ERROR - 2021-06-27 15:58:06 --> Query error: Table 'alter_priv_sewa.kategori' doesn't exist - Invalid query: SELECT *
FROM `kategori`
WHERE `id_kategori` = '9'
ERROR - 2021-06-27 16:13:55 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 105
ERROR - 2021-06-27 16:20:17 --> Query error: Table 'alter_priv_sewa.kategori' doesn't exist - Invalid query: SELECT *
FROM `kategori`
WHERE `id_kategori` = '9'
ERROR - 2021-06-27 16:35:42 --> Severity: Notice --> Undefined variable: merk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 30
ERROR - 2021-06-27 16:35:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 30
ERROR - 2021-06-27 16:40:35 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 135
ERROR - 2021-06-27 16:56:38 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\alter_private\sewamobil\application\models\M_loginuser.php 20
ERROR - 2021-06-27 16:59:18 --> Severity: error --> Exception: syntax error, unexpected '$where_clause' (T_VARIABLE) C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 163
ERROR - 2021-06-27 17:30:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` <= '2021-06-27 00:00:00'
AND `tgl_akhir` >= '2021-06-28 00:00:00'
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and  <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:31:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and  <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and  <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:31:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_akhir` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:31:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_akhir` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:31:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_akhir` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:31:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_akhir` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:33:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_akhir` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:33:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_akhir` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:33:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:36:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:36:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:36:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-0' at line 6 - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `tgl_akhir` >= `2021-06-27` `00:00:00` and `tgl_mulai` <= `2021-06-28` `00:00:00`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:37:20 --> Query error: Unknown column '2021-06-27' in 'where clause' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= `2021-06-27` and `tgl_mulai` <= `2021-06-28`
AND `tgl_akhir` >= `2021-06-27` and `tgl_mulai` <= `2021-06-28`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 17:38:29 --> Query error: Unknown column '2021-06-27' in 'where clause' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`gambar`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE kendaraan.id NOT IN (SELECT `id_kendaraan`
FROM `transaksi`
WHERE `tgl_mulai` >= '2021-06-27' and `tgl_mulai` <= '2021-06-28'
AND `tgl_akhir` >= `2021-06-27` and `tgl_mulai` <= `2021-06-28`
AND `status_pembayaran` NOT IN('Batal'))
ERROR - 2021-06-27 18:03:20 --> Severity: Notice --> Undefined variable: tgl_mula C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 161
