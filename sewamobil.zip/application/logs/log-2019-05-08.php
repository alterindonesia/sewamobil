<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-08 07:14:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\dinda\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2019-05-08 07:14:58 --> Unable to connect to the database
ERROR - 2019-05-08 07:14:58 --> Severity: Warning --> include(C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
ERROR - 2019-05-08 07:14:58 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\alter_private\dinda\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\alter_private\dinda\system\core\Exceptions.php 182
