<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 123
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 75
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:06:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 101
ERROR - 2018-05-07 10:09:58 --> Severity: Warning --> Missing argument 1 for Index::invoice(), called in C:\xampp\htdocs\alter_private\maya\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 155
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 157
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 159
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 161
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 52
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 89
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 97
ERROR - 2018-05-07 10:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 101
ERROR - 2018-05-07 10:10:11 --> Severity: Warning --> Missing argument 1 for Index::invoice(), called in C:\xampp\htdocs\alter_private\maya\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 155
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 157
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 159
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 161
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 52
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 10:10:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 89
ERROR - 2018-05-07 10:10:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 97
ERROR - 2018-05-07 10:10:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 101
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 52
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 75
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 89
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 97
ERROR - 2018-05-07 10:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 101
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 123
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 75
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:12:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 101
ERROR - 2018-05-07 10:47:22 --> Query error: Column 'id_pembeli' cannot be null - Invalid query: INSERT INTO `transaksi` (`id_pembeli`, `id_kota`, `alamat`) VALUES (NULL, '1', 'Aceh')
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 123
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 75
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 10:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 101
ERROR - 2018-05-07 10:48:38 --> Severity: error --> Exception: Call to undefined method CI_Session::login_user() C:\xampp\htdocs\alter_private\maya\application\views\user\checkout.php 79
ERROR - 2018-05-07 10:50:04 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) C:\xampp\htdocs\alter_private\maya\application\views\user\checkout.php 81
ERROR - 2018-05-07 11:53:02 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 123
ERROR - 2018-05-07 11:53:02 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 75
ERROR - 2018-05-07 11:53:02 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 11:53:02 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 11:56:57 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 75
ERROR - 2018-05-07 11:56:57 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 11:56:57 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 78
ERROR - 2018-05-07 11:57:07 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 76
ERROR - 2018-05-07 11:57:07 --> Severity: Notice --> Undefined property: stdClass::$berat C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 76
ERROR - 2018-05-07 12:36:59 --> Severity: Warning --> Missing argument 1 for Index::invoice(), called in C:\xampp\htdocs\alter_private\maya\system\core\CodeIgniter.php on line 514 and defined C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 155
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 157
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 159
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 161
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 40
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 43
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 46
ERROR - 2018-05-07 12:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 49
ERROR - 2018-05-07 12:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 52
ERROR - 2018-05-07 12:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 58
ERROR - 2018-05-07 12:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\invoice.php 85
ERROR - 2018-05-07 12:37:14 --> 404 Page Not Found: Index/pesanan
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined property: stdClass::$nama_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 49
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 50
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:41:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 50
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:43:12 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 50
ERROR - 2018-05-07 12:43:13 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:43:13 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:43:13 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:43:13 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:43:13 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 50
ERROR - 2018-05-07 12:44:39 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:44:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:44:39 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:44:39 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:44:39 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:44:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:45:59 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:45:59 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:45:59 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:45:59 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:45:59 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:14 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:46:14 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:14 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:14 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:46:14 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:22 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:46:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:22 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:22 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:46:22 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:28 --> Severity: Notice --> Undefined property: stdClass::$harga C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 51
ERROR - 2018-05-07 12:46:28 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:28 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:28 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:46:28 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:54 --> Severity: Notice --> Undefined property: stdClass::$jumlah_produk C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:54 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 52
ERROR - 2018-05-07 12:46:54 --> Severity: Notice --> Undefined property: stdClass::$harga_total C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 53
ERROR - 2018-05-07 12:46:55 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:46:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 62
ERROR - 2018-05-07 12:48:38 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 61
ERROR - 2018-05-07 12:48:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 61
ERROR - 2018-05-07 12:48:51 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 61
ERROR - 2018-05-07 12:48:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 61
ERROR - 2018-05-07 12:49:12 --> Severity: Notice --> Undefined variable: pembeli C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 61
ERROR - 2018-05-07 12:49:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 61
ERROR - 2018-05-07 12:49:30 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 90
