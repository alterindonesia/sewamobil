<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-18 03:31:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-18 03:31:22 --> Unable to connect to the database
ERROR - 2018-05-18 03:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\maya\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-18 03:32:01 --> Unable to connect to the database
ERROR - 2018-05-18 03:35:50 --> Severity: Notice --> Undefined property: stdClass::$id_transaksii C:\xampp\htdocs\alter_private\maya\application\views\user\pesanan.php 56
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\alter_private\maya\application\controllers\Konfirmasi.php 27
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 18
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 18
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 22
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 22
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Undefined variable: transaksi C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 23
ERROR - 2018-05-18 03:42:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\maya\application\views\user\konfirmasi.php 23
ERROR - 2018-05-18 03:51:17 --> 404 Page Not Found: Index/konfirmasi
ERROR - 2018-05-18 04:09:36 --> Severity: Notice --> Undefined index: berat C:\xampp\htdocs\alter_private\maya\application\controllers\Index.php 131
