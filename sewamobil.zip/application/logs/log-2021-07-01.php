<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-01 00:01:42 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:01:50 --> Query error: Unknown column 'nama_merk' in 'where clause' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`file`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `type` LIKE '%toyota%' ESCAPE '!'
OR  `nama_merk` LIKE '%toyota%' ESCAPE '!'
ERROR - 2021-07-01 00:02:01 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:02:04 --> Query error: Unknown column 'nama_merk' in 'where clause' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`file`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `type` LIKE '%type%' ESCAPE '!'
OR  `nama_merk` LIKE '%type%' ESCAPE '!'
ERROR - 2021-07-01 00:02:10 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:02:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:02:20 --> Query error: Unknown column 'nama_merk' in 'where clause' - Invalid query: SELECT `kendaraan`.`type`, `kendaraan`.`deskripsi`, `kendaraan`.`transmisi`, `kendaraan`.`bahan_bakar`, `kendaraan`.`kategori_plat`, `kendaraan`.`jumlah_kursi`, `kendaraan`.`id` as `id_kendaraan`, `kendaraan`.`file`, `kendaraan`.`harga_include_driver`, `kendaraan`.`harga_exclude_driver`, `merk`.`nama` as `nama_merk`
FROM `kendaraan`
LEFT JOIN `merk` ON `merk`.`id` = `kendaraan`.`id_merk`
WHERE `type` LIKE '%hi%' ESCAPE '!'
OR  `nama_merk` LIKE '%hi%' ESCAPE '!'
ERROR - 2021-07-01 00:02:54 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:02:56 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:03:04 --> Severity: Notice --> Undefined variable: merk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 30
ERROR - 2021-07-01 00:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 30
ERROR - 2021-07-01 00:03:04 --> Severity: Notice --> Undefined variable: params C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 50
ERROR - 2021-07-01 00:03:04 --> Severity: Notice --> Undefined variable: params C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_hasil_pencarian.php 56
ERROR - 2021-07-01 00:03:04 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:03:23 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:07:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:07:22 --> Severity: Notice --> Undefined variable: merk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 30
ERROR - 2021-07-01 00:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 30
ERROR - 2021-07-01 00:07:23 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:08:37 --> Severity: Notice --> Undefined variable: merk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 30
ERROR - 2021-07-01 00:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 30
ERROR - 2021-07-01 00:08:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:08:49 --> Severity: Notice --> Undefined variable: merk C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 30
ERROR - 2021-07-01 00:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 30
ERROR - 2021-07-01 00:08:50 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:09:15 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\alter_private\sewamobil\application\controllers\Kendaraan.php 18
ERROR - 2021-07-01 00:09:37 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:18 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:18 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:19 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:19 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:19 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:19 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `merk`
WHERE `type` LIKE '%innova%' ESCAPE '!'
ERROR - 2021-07-01 00:10:44 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:10:47 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:11:02 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:11:06 --> 404 Page Not Found: Kendaraan/merk
ERROR - 2021-07-01 00:11:08 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:16:07 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Undefined property: mysqli::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Undefined property: mysqli::$nama C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Undefined property: mysqli_result::$nama C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:11 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:16:22 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Undefined property: mysqli::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Undefined property: mysqli::$nama C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Undefined property: mysqli_result::$nama C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:26 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:16:40 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Undefined property: mysqli::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Undefined property: mysqli::$nama C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Undefined property: mysqli_result::$nama C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 32
ERROR - 2021-07-01 00:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\front\v_searching.php 33
ERROR - 2021-07-01 00:16:48 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:12 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:15 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:18 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:19 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:21 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:24 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:28 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 00:18:38 --> 404 Page Not Found: Assets/front
ERROR - 2021-07-01 22:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-07-01 22:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\alter_private\sewamobil\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-07-01 22:42:02 --> Unable to connect to the database
ERROR - 2021-07-01 22:42:02 --> Unable to connect to the database
ERROR - 2021-07-01 22:45:16 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:45:45 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:45:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:45:56 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-07-01 22:45:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:46:09 --> Unable to load the requested class: Grocery_CRUD
ERROR - 2021-07-01 22:46:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:50:50 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:50:52 --> Severity: Notice --> Undefined property: stdClass::$no_telpon C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 72
ERROR - 2021-07-01 22:50:52 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 75
ERROR - 2021-07-01 22:50:52 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 81
ERROR - 2021-07-01 22:50:52 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 87
ERROR - 2021-07-01 22:50:52 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 93
ERROR - 2021-07-01 22:50:52 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:51:03 --> Severity: Notice --> Undefined property: stdClass::$no_telpon C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 71
ERROR - 2021-07-01 22:51:03 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 74
ERROR - 2021-07-01 22:51:03 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 80
ERROR - 2021-07-01 22:51:03 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 86
ERROR - 2021-07-01 22:51:03 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 92
ERROR - 2021-07-01 22:51:03 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:51:13 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 73
ERROR - 2021-07-01 22:51:13 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 79
ERROR - 2021-07-01 22:51:13 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 85
ERROR - 2021-07-01 22:51:13 --> Severity: Notice --> Undefined property: stdClass::$status_verifikasi C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_index.php 91
ERROR - 2021-07-01 22:51:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:53:30 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:53:56 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:54:18 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:54:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:55:40 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 22:55:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_detail.php 158
ERROR - 2021-07-01 22:55:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_detail.php 169
ERROR - 2021-07-01 22:57:53 --> Severity: error --> Exception: syntax error, unexpected ':', expecting ',' or ';' C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_detail.php 180
ERROR - 2021-07-01 22:58:22 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:01:53 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:01:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:02:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:02:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:02:36 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:08:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:08:27 --> Severity: error --> Exception: syntax error, unexpected '{', expecting ':' C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_ubah.php 200
ERROR - 2021-07-01 23:08:54 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\alter_private\sewamobil\application\views\admin\useradmin\v_ubah.php 208
ERROR - 2021-07-01 23:09:24 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:09:33 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:24:27 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:25:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:25:15 --> 404 Page Not Found: admin/Useradmin/tambah
ERROR - 2021-07-01 23:27:51 --> 404 Page Not Found: admin/Useradmin/tambah
ERROR - 2021-07-01 23:30:19 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:30:21 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:31:10 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:31:23 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:31:47 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:31:55 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:31:58 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:32:12 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:32:18 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:32:28 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:32:34 --> 404 Page Not Found: Assets/admin
ERROR - 2021-07-01 23:32:51 --> 404 Page Not Found: Assets/admin
