<!-- jQuery -->

<script>
    $(document).ready(function(){
       $('.<?php echo isset($active)?$active:'dash';?>').addClass('active');
    });
</script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

