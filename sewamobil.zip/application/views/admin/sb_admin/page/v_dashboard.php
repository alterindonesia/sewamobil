<!-- Morris Charts CSS -->
<link href="css/plugins/morris.css" rel="stylesheet">
<div class="row">
    <div class="col-lg-3 col-md-6">
    </div>
</div>
<!-- /.row -->

<script src="js/jquery.js"></script>
<!-- Morris Charts JavaScript -->
<script src="js/plugins/morris/raphael.min.js"></script>
<script src="js/plugins/morris/morris.min.js"></script>
<script src="js/plugins/morris/morris-data.js"></script>